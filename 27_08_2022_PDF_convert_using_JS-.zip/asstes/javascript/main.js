function generate() {
  var doc = new jsPDF("p", "pt", "letter");
  margins = {
    top: 150,
    bottom: 60,
    left: 40,
    right: 40,
    width: 600,
  };
  const simple_table = document.querySelector("#simple_table");
  const theadTd = Array.from(simple_table.querySelectorAll("thead th"));
  const tbodyTr = Array.from(simple_table.querySelectorAll("tbody tr"));

  const theadDataArr = theadTd.map((item) => {
    return item.innerHTML;
  });

  const tbodyDataArr = tbodyTr.map((item) => {
    const td = Array.from(item.querySelectorAll("td")).map((ele) => {
      return ele.innerText;
    });
    return td;
  });
  const red = "red";

  doc.autoTable({
    startY: 70,
    theme: "grid",
    head: [theadDataArr],
    body: tbodyDataArr,
    theme: "plain",
    // theme: 'striped'|'grid'|'plain'
    styles: {
      minCellHeight: 40,
    },
    didParseCell: (table) => {
      if (table.section === "head") {
        table.cell.styles.textColor = "red";
        table.cell.styles.fillColor = "green";
      }
    },
    // tableLineColor: [255, 255, 255],
    // tableLineWidth: 1,

    didDrawCell: (head) => {
      doc.setLineWidth(1);
      if (head.section === "body") {
        doc.setDrawColor(0, 0, 0);
        // doc.line(head.cursor.x, head.cursor.y, 570, head.cursor.y);doc.internal.pageSize.width
        doc.line(
          head.cursor.x,
          head.cursor.y,
          doc.internal.pageSize.width - 42,
          head.cursor.y
        );
      }
      console.log(head);
      if (head.cell.raw == "Asguard") {
        doc.setDrawColor(223, 37, 37);
        doc.line(
          head.cursor.x,
          head.cursor.y + head.row.height,
          head.cursor.x,
          head.cursor.y + head.row.height
        );
        doc.line(
          head.cursor.x,
          head.cursor.y + head.row.height,
          head.cursor.x,
          head.cursor.y + head.row.height
        );
        console.log("happy");
      }
    },
    headerStyles: {
      cellPadding: {
        top: 10,
        left: 20,
      },
    },
    bodyStyles: {},
  });

  doc.save("Marks_Of_Students.pdf");
}

function generateExcell() {

  $("#simple_table").table2excel({
    exclude: ".noExl",

    name: "Worksheet Name",

    filename: "SomeFile",

    fileext: ".xlsx",

    exclude_img: true,

    exclude_links: true,

    exclude_inputs: true,
  });
}
